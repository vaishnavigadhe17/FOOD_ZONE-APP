package com.normal.exceptions;

public class RestaurantException extends Exception{
	
	public RestaurantException() {
		
	}
	
	
	public RestaurantException(String message){
		super(message);
	}
	
	
	

}
