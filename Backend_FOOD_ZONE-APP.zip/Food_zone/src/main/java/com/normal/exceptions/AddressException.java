package com.normal.exceptions;

public class AddressException extends Exception{
	
}