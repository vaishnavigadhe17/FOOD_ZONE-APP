package com.normal.exceptions;

import java.time.LocalDate;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ErrorDetails {
	
	private LocalDate errorDate;
	
	private String message;
	
	private String details;

	

	public void setDetails(String description) {
		// TODO Auto-generated method stub
		
	}

	public void setMessage(String message2) {
		// TODO Auto-generated method stub
		
	}

	public LocalDate getErrorDate() {
		return errorDate;
	}

	public void setErrorDate(LocalDate errorDate) {
		this.errorDate = errorDate;
	}

	public String getMessage() {
		return message;
	}

	public String getDetails() {
		return details;
	}

	public ErrorDetails(LocalDate errorDate, String message, String details) {
		super();
		this.errorDate = errorDate;
		this.message = message;
		this.details = details;
	}

	public ErrorDetails() {
		// TODO Auto-generated constructor stub
	}

	public void setLocalDate(LocalDate now) {
		// TODO Auto-generated method stub
		
	}

	
	
	
}
