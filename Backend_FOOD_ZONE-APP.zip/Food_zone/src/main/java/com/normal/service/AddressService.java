package com.normal.service;

import java.util.List;

import com.normal.model.Address;

public interface AddressService {
    Address addAddress(Address address);
    Address updateAddress(Address address);
    Address getAddress(Integer addressId);
    Address deleteAddress(Integer addressId);
    List<Address> getAllAddresses();
}

