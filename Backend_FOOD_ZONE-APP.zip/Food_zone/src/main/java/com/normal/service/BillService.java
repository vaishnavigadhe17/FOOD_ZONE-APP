package com.normal.service;

import com.normal.exceptions.BillException;
import com.normal.exceptions.CustomerException;
import com.normal.exceptions.ItemException;
import com.normal.model.Bill;

public interface BillService {
	
	public Bill addBill(Bill bill) throws BillException;
	
	public Bill updateBill(Bill bill)throws BillException;
	
	public Bill removeBill(Integer billId)throws BillException;
	
	public Bill viewBill(Integer billId)throws BillException;
	
	public String generateTotalBillById(Integer customerId)throws ItemException,CustomerException;
	

}
