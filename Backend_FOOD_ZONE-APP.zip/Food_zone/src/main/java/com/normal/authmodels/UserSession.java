package com.normal.authmodels;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
public class UserSession {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@Column(unique =  true)
	private Integer userId;
	private String UUID;
	private LocalDateTime timeStamp;

	
	public UserSession(Integer userId, String uuid, LocalDateTime localDateTime) {
		super();
		this.userId = userId;
		this.UUID = uuid;
		this.timeStamp = localDateTime;
	}


	public Integer getUserId() {
		// TODO Auto-generated method stub
		return null;
	}


	public Integer getId() {
		// TODO Auto-generated method stub
		return null;
	}


	public String getUUID() {
		return UUID;
	}


	public void setUUID(String uUID) {
		UUID = uUID;
	}


	public LocalDateTime getTimeStamp() {
		return timeStamp;
	}


	public void setTimeStamp(LocalDateTime timeStamp) {
		this.timeStamp = timeStamp;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public void setUserId(Integer userId) {
		this.userId = userId;
	}


	@Override
	public String toString() {
		return "UserSession [id=" + id + ", userId=" + userId + ", UUID=" + UUID + ", timeStamp=" + timeStamp + "]";
	}


	public UserSession(Integer id, Integer userId, String uUID, LocalDateTime timeStamp) {
		super();
		this.id = id;
		this.userId = userId;
		UUID = uUID;
		this.timeStamp = timeStamp;
	}
	

}
