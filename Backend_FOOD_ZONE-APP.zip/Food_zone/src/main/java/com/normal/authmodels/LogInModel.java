package com.normal.authmodels;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class LogInModel {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer userId1;
	@NotNull
	private Integer userId;
	private String userName1;
	private String password1;
	
	


	@NotNull
	@Pattern(regexp="[a-zA-Z]{5,15}", message = "Username must be of length 5-15 alphabetical characters")
	private String userName;

	@NotNull
	@Pattern(regexp="[a-zA-Z0-9]{5,20}", message="Password must be of length 5-20 alphanumeric characters")
	private String password;


	public Integer getUserId() {
		// TODO Auto-generated method stub
		return null;
	}
	public Object getPassword() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getUserName() {
		return userName1;
	}
	public void setUserName(String userName) {
		this.userName1 = userName;
	}
	public void setUserId(Integer userId) {
		this.userId1 = userId;
	}
	public void setPassword(String password) {
		this.password1 = password;
	}
	
	public LogInModel(@NotNull Integer userId, String userName, String password) {
		super();
		this.userId1 = userId;
		this.userName1 = userName;
		this.password1 = password;
	}
	
	

}
