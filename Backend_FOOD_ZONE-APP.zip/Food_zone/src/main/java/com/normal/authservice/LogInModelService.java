package com.normal.authservice;

import com.normal.authexceptions.AuthorizationException;
import com.normal.authmodels.LogInModel;

public interface LogInModelService {
	
	public String LogIn(LogInModel login) throws AuthorizationException;
	
	public String LogOut(String key) throws AuthorizationException;

}
