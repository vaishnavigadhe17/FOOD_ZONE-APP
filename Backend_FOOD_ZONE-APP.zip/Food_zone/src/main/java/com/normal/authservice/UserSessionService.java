package com.normal.authservice;

import com.normal.authexceptions.AuthorizationException;
import com.normal.authmodels.SignUpModel;
import com.normal.authmodels.UserSession;

public interface UserSessionService {
	
	public UserSession getUserSession(String key) throws AuthorizationException;
	
	public Integer getUserSessionId(String key) throws AuthorizationException;
	
	public SignUpModel getSignUpDetails(String key) throws AuthorizationException;
	

}
