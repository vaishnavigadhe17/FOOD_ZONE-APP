package com.normal.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.normal.model.Address;

public interface AddressDAO extends JpaRepository<Address, Integer> {
}

