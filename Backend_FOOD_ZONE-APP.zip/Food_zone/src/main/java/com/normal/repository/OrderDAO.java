package com.normal.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.normal.model.OrderDetails;


@Repository
public interface OrderDAO extends JpaRepository<OrderDetails, Integer>{

}
