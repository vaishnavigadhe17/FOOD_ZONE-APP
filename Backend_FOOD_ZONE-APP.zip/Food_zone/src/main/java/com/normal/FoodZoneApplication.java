package com.normal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodZoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodZoneApplication.class, args);
	}

}
