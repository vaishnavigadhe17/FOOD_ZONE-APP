package com.normal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodZoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
